/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
BrowserID.Modules.IsThisYourComputer = (function() {
  "use strict";

  var bid = BrowserID,
      dom = bid.DOM,
      user = bid.User,
      errors = bid.Errors,
      domHelpers = bid.DOMHelpers,
      SCREEN_SELECTOR = "#wait",
      SKIN_CLASS = "black",
      email;

  var Module = bid.Modules.PageModule.extend({
    start: function(options) {
      options = options || {};
      email = options.email;

      var self = this;

      // The "signing in" screen is shown right now. Hide it while showing this
      // screen.
      self.hideWarningScreens();

      // The error screen normally has a button row. Hide the button row before
      // rendering the error or CSS transitions make the content shift around.
      dom.addClass(SCREEN_SELECTOR, SKIN_CLASS);

      self.renderWait("is_this_your_computer", options);

      // renderWait does not automatically focus the first input element or
      // button, so it must be done manually.
      dom.focus("#this_is_my_computer");

      self.click("#this_is_my_computer", self.yes);
      self.click("#this_is_not_my_computer", self.no);

      // Force all the buttons to be of equal width
      self.bind(window, "resize", function() {
        domHelpers.makeEqualWidth("#your_computer_content button");
      });
      domHelpers.makeEqualWidth("#your_computer_content button");

      Module.sc.start.call(self, options);
    },

    yes: function() {
      this.confirmed(true);
    },

    no: function() {
      this.confirmed(false);
    },

    confirmed: function(status) {
      var self=this;

      dom.removeClass(SCREEN_SELECTOR, SKIN_CLASS);
      user.setComputerOwnershipStatus(status, function() {
        self.publish("user_computer_status_set", { users_computer: status });
      }, self.getErrorDialog(errors.setComputerOwnershipStatus));
    }
  });


  return Module;

}());
