Currently this is used only by tests/auth_with_assertion.js

Most examples have a scripts/serve_example*.js so you can do manual testing with it. This one does not... files are used only programatically in the unit tests.