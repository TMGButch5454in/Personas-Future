#!/bin/bash

# don't run automation tests at git push time
# node automation-tests/scripts/post-update.js

scripts/show_config.js
