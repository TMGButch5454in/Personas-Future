Installing Dependencies on Ubuntu
---------------------------------

Run the following to install necessary dependencies:

    sudo apt-add-repository ppa:chris-lea/node.js
    sudo apt-get update
    sudo apt-get install python-software-properties
    sudo apt-get install nodejs git-core libgmp3-dev g++ make
