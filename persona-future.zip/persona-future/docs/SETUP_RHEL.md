Installing Dependencies on RedHat Enterprise Linux and Related Derivatives
---------------------------------
[Red Hat Enterprise Linux Derivatives](https://en.wikipedia.org/wiki/Red_Hat_Enterprise_Linux_derivatives)

Run the following to install necessary dependencies:

    sudo yum install gcc-c++ nodejs gmp-devel expat-devel
